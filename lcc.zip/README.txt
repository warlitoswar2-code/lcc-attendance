# Student Attendance Monitoring System (Prototype)

## Run it
1. Unzip the project.
2. Open `index.html` in Chrome, Safari, or Edge.
3. Sign in using one of the demo accounts:
   - Teacher: `teacher@lcc.edu.ph` / `teacher123`
   - Admin: `admin@lcc.edu.ph` / `admin123`

## Publish free with GitHub Pages
1. Create a free account at https://github.com/ if you do not already have one.
2. Create a new public repository, for example `lcc-attendance`.
3. Upload `index.html` to the repository root.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for the published URL shown in the Pages section.

## Important limitations
This is a front-end demonstration prototype. Data is stored in the browser on the device used to open the page (localStorage); it is not a shared school database. Login is demo-only and is not secure authentication. SMS messages are simulated and are NOT sent to parents. Real deployment needs a secure backend/database, administrator-approved accounts, proper privacy/security controls, and a compatible paid SMS gateway. Do not enter real student or parent personal information into this demo.
